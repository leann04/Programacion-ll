/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajopractico1;

import java.util.Scanner;

/**
 *
 * @author leanf
 */
public class Ejercicio3 {
        public static void main(String[] args) {
             Scanner scanner = new Scanner(System.in);
       
        System.out.print("Ingrese su edad: ");
        int edad = scanner.nextInt();
        
        String clasificacion;
        if (edad < 12) {
            clasificacion = "Niño";
        } else if (edad <= 17) {
            clasificacion = "Adolescente";
        } else if (edad <= 59) {
            clasificacion = "Adulto";
        } else {
            clasificacion = "Adulto mayor";
        }
        
        System.out.println("Eres un " + clasificacion + ".");
    }
}
