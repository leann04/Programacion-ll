/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajopractico1;

import java.util.Scanner;

/**
 *
 * @author leanf
 */
public class Ejercicio4 {
            public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);
        
        System.out.print("Ingrese el precio del producto: ");
        double precio = scanner.nextDouble();
        System.out.print("Ingrese la categoría del producto (A, B o C): ");
        char categoria = scanner.next().toUpperCase().charAt(0);
        
        double porcentajeDescuento = 0;
        switch (categoria) {
            case 'A':
                porcentajeDescuento = 10;
                break;
            case 'B':
                porcentajeDescuento = 15;
                break;
            case 'C':
                porcentajeDescuento = 20;
                break;
            default:
                System.out.println("Categoría inválida.");
                return;
        }
        
        double descuento = precio * (porcentajeDescuento / 100);
        double precioFinal = precio - descuento;
        
        System.out.println("Descuento aplicado: " + (int)porcentajeDescuento + "%");
        System.out.println("Precio final: " + precioFinal);
    }
}
