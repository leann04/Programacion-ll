/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajopractico1;

import java.util.Scanner;

/**
 *
 * @author leanf
 */
public class Ejercicio5 {
    public static void main( String[] args){
        Scanner scanner = new Scanner(System.in);
        
        
        int numero;
        int sumaPares = 0;
        
        while (true) {
            System.out.print("Ingrese un número (0 para terminar): ");
            numero = scanner.nextInt();
            
            if (numero == 0) {
                break;
            }
            
            if (numero % 2 == 0) {
                sumaPares += numero;
            }
        }
        
        System.out.println("La suma de los números pares es: " + sumaPares);
    }
    
    }
